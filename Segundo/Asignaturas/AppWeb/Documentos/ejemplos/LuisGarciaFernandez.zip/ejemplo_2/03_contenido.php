﻿<?php
	print "<h2><center>Ejercicios de php</center></h2>";
	print "<p>Estamos en ASIR 2. Para probar los ejercicios PHP	
	elige el ejercicio correspondiente en el menú de la izquierda.</p>"; 
?>
